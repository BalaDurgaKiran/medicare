import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analgesics',
  templateUrl: './analgesics.component.html',
  styleUrls: ['./analgesics.component.css']
})
export class AnalgesicsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
