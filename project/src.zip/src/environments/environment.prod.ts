export const environment = {
  production: true,
  apiUrl:"localhost:8080"
  
};
